Nume: Grigoras Teodora
Grupa 334 AA

Prezentarea solutiei:
	Starea 0 este o stare comuna in care hotarasc actiunile pe care vreau sa le desfasor. De asemenea actualizez row si col cu valoarea de pornire (zero)

MIRROR
	variabile:
		- i_pix il folosesc pentru a stoca in el valoarea pivelului din a doua jumatate de poza
		-o_pix pentru stocarea pixelului din prima jumatate
	Rezumat: parcurg matricea pana la jumatate si interschimb pixelul curent cu oglinditul lui (63-row) ajutanduma de variabilele i_pix si o_pix.
	-in starea 1 salvez pixelul din prima jumatate a pozei (actualul) in i_pix.
	-in state2 salvez pixelul din a doua jumatate a pozei in o_pix si pun in pixelul din a doua jumatatea valoarea salvata in i_pix.
	- in state 3 ma intorc in prima jumatate sin pun in ea pixelul salvat in o_pix.
	- in state 4 actualizez randul si coloana pentru urmatorul pixel pe care vreau sa-l oglindesc si ma intorc la state1 pt a repeta operatia de interschimbare. Daca am ajuns la finalul primei jumatati, anunt terminarea mirror si merg in starea 0.
	- din starea 0 hotarasc plecarea spre GRAY.
GRAY
	variabile: max (maximul dintre canalele lui in_pix), min ( minimul dintre canalele lui in_pix), med (media dintre acestea)
	Rezumat: parcurg matricea, fac media dintre min si max si salvez in canalul G rezultatul. Pe celelalte canale, R si B, le fac 0.
	- incep din state6 unde calculez max si min
	- in state7 calculez media
	- din 7 trec in 5 si aici scriu in canalul G al lui out_pix valoarea medie si pe restul canalelor le fac 0.
	- din 5 trec in 8 si unde trec la linia si coloana urmatoar. Daca ajung la ultima linie si ultima coloana anunt terminarea lui GRAY si ma intorc in state 5 pentru a aseza si in ultimul pixel valoarea med.
SHARNESS
	variabile:
	- a0, b0, c0, a1, b1, c1, a2, b2, c2 pixelii matricei formate de in_pix si vecinii lui.
	- aux suma vecinilor lui in_pix
	- sum matricea in care pun valorile calculate pentru acest filtru
	- stop e o conditie de oprire in cazul in care am ajuns la finalul copierii peste matricea originala a celei de sum.

	Rezumat: am lucrat doar cu canalul G
		Pentru fiecare in_pix, am creat matricea lui de 3 pe 3 si am pus in sum valoarea corespunzatoare.
		Dupa calcularea tuturor valorilor pentru sum, trec la pasul in care parcurg iar matricea originala si pun peste ea valorile din sum;
	OBSERVATIE: la incheierea calculelor pentru sum, ar trebui sa se treaca la starea in care copiez valorile. Doar ca acest lucru nu se intampla. Automatul meu nu trece la starea lui next_state pe care eu o setez.
	- starea 9 setez a0,1,2; b0,1,2; c0,1,2.
	- urmeaza starea 11 unde fac calculele pt sum si trec la starea 10 unde trec la pixelul urmator.
	- in starea 10, daca ajung la finalul de parcurgere, fac filter done=1;
	- in stararea 10 am un if in care daca filter_done e 1 trec la copiere. IN REALITATE NU SE INTAMPLA ASTA.
	DECI NU IMI TRECE DIN STAREA 10 IN 12.
